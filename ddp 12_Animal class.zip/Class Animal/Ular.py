from Animals import *
class Ular(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, bisa, warna):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.bisa = bisa 
        self.warna = warna 
        
    def cetak_Ular(self):
        super().cetak()
        print(f'hewan ini tidak memiliki {self.bisa} dan hewan ini berwarna {self.warna}')
        
    def cetak_Ular1(self):
        super().cetak()
        print(f'hewan ini memiliki {self.bisa} dan hewan ini berwarna {self.warna}')
        
        
# Ular Python
print('========== Ular Python ==========')
Python = Ular('Ular Python', 'Daging', 'Hutan', 'Bertelur', 'bisa', 'Batik')
Python.cetak_Ular()
print('========== Object Pertama ==========')
print()

# Ular Cobra
print('========== Ular Cobra ==========')
Cobra = Ular('Ular Cobra', 'Daging', 'Hutan', 'Bertelur', 'bisa', 'Abu-abu')
Cobra.cetak_Ular1()
print('========== Object Ke dua ==========')
        

