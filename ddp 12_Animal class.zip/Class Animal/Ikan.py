from Animals import *

class ikan(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, warna_ikan, jenis_ikan):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.warna = warna_ikan
        self.jenis = jenis_ikan
        
    def cetak_ikan(self):
        super().cetak()
        print(f'Warna ikan ini adalah warna {self.warna} dan ikan ini jenisnya ikan {self.jenis}')
        
# Ikan Kerapu 
print('========== Ikan Kerapu ==========')
Kerapu = ikan('Ikan Kerapu', 'Ikan Kecil', 'air', 'beretelur', 'orange', 'air asin')
Kerapu.cetak_ikan()
print('========== Object Pertama ==========')
print()

# Ikan Tuna 
print('========== Ikan Tuna ==========')
Tuna = ikan('Ikan Tuna', 'Ikan Kecil', 'air', 'beretelur', 'Biru', 'air asin')
Tuna.cetak_ikan()
print('========== Object Ke dua ==========')