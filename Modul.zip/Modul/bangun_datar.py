import math

def l_segitiga(alas, tinggi):
    luas = 1.2*alas*tinggi
    print(f'luas segitiga 1.2 * {alas} * {tinggi} = {luas}')

import math

def l_trapesium(a, b, tinggi):
    luas = 1.2*(a+b)*tinggi
    print(f'luas segitiga 1.2 * ({a} + {b}) * {tinggi} = {luas}')

import math

def l_persegi(sisi):
    luas = sisi*sisi
    keliling = sisi*sisi*sisi*sisi
    print(f'luas Persegi {sisi} * {sisi} = {luas}')
    print(f'Keliling Persegi adlah {keliling}')

import math

def l_persegi_panjang(lebar, panjang):
    luas = lebar*panjang
    print(f'luas Persegi Panjang {lebar} * {panjang} = {luas}')

import math

def l_lingkaran(r1, r2):
    luas = 3.14 * r1 * r2
    print(f'Luas Lingkaran 3.14 * {r1} * {r2}')

import math

def l_layang_layang(d1, d2):
    luas = 1.2*d1*d2
    print(f'luas Layang-layang  1.2 * {d1} * {d2} = {luas}')

import math

def l_jajar_genjang(alas, tinggi):
    luas = alas*tinggi
    print(f'luas Jajar Genjang  {alas} * {tinggi} = {luas}')

import math

def l_belah_ketupat(d1, d2):
    luas = 1.2*d1*d2
    print(f'luas Belah Ketupat 1.2 * {d1} * {d2} = {luas}')